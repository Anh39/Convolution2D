# 1 "D:/Programming/Storage/Class/2024-2025/Embed/convolution2d/convolution2d.c"
# 1 "<built-in>"
# 1 "<command-line>"
# 1 "D:/Programming/Storage/Class/2024-2025/Embed/convolution2d/convolution2d.c"
# 1 "D:/Programming/Storage/Class/2024-2025/Embed/convolution2d/convolution2d.h" 1
# 11 "D:/Programming/Storage/Class/2024-2025/Embed/convolution2d/convolution2d.h"
void convolution2d(int I[10][5], int K[3][2], int J[10 -3 +1][5 -2 +1]);
# 2 "D:/Programming/Storage/Class/2024-2025/Embed/convolution2d/convolution2d.c" 2

void convolution2d(int I[10][5], int K[3][2], int J[10 -3 +1][5 -2 +1]) {
I_LOOP_ROW:
 for (int i=0; i<10 -3 +1;i++) {
I_LOOP_COL:
        for (int j=0; j<5 -2 +1;j++) {
            int sum=0;
K_LOOP_ROW:
            for (int ik=0; ik < 3; ik++) {
K_LOOP_COL:
                for(int jk=0; jk < 2; jk++) {
                    sum += I[i+ik][j+jk] * K[ik][jk];
                }
            }
            J[i][j] = sum;
        }
    }
}
